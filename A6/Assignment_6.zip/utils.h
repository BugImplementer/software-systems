/*
 A header file for utils.c to share information with other developers
 without verbal communication.
 **********************************************************
 * Author      Dept.          Date         Notes
 **********************************************************
 * Xinyi Zhu   Comp.Science   Apr 14 2020  Final version.

*/

void parse(char* line, int *coefficient, int *exponent);

int powi(int base, int exponent);
