/*
 A header file for poly.c to share information with other developers
 without verbal communication.
 **********************************************************
 * Author      Dept.          Date         Notes
 **********************************************************
 * Xinyi Zhu   Comp.Science   Apr 14 2020  Final version.

*/

struct PolyTerm 
{
	int coeff;
	int expo;
	struct PolyTerm *next;
};

extern struct PolyTerm head;

int addPolyTerm(int coefficient, int exponent);

void displayPolynomial();

int evaluatePolynomial(int base);
