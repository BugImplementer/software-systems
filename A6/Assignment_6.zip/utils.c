#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/*
 Program two functions to parse a line and calculate exponentiation.
 **********************************************************
 * Author      Dept.          Date         Notes
 **********************************************************
 * Xinyi Zhu   Comp.Science   Apr 12 2020  Initial version.
 * Xinyi Zhu   Comp.Science   Apr 13 2020  Added error handling.
 * Xinyi Zhu   Comp.Science   Apr 14 2020  Final version.

*/

void parse(char* line, int* coeff, int* expo) {
	//sscanf(line, "%d %d", &coeff, &expo);

	char* first = strtok(line, " ");
	int a = atoi(first);
	*coeff = a;

	char* second = strtok(NULL, " ");
	int b = atoi(second);
	*expo = b;
	
}

int powi(int x, int expo) {
	int count = 0;
	int result = 1;
	while(count < expo) {
		result *= x;
		count++;
	}
	return result;
}

/*
int main(int argc, char* argv[]) {
        char line[] = "2 3";      
        //int *coeff=NULL, *expo=NULL;         
        int coeff, expo;
  
        
        parse(line, &coeff, &expo);
        printf("%d\n", coeff);
        printf("%d\n", expo);
        int a = powi(coeff, expo);
        printf("%d\n", a);

      

}
*/

