#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "utils.h"

/*
 Program to make a linked list to store a polynomial of arbitraty lenth.
 **********************************************************
 * Author      Dept.          Date         Notes
 **********************************************************
 * Xinyi Zhu   Comp.Science   Apr 12 2020  Initial version.
 * Xinyi Zhu   Comp.Science   Apr 12 2020  Added error handling.
 * Xinyi Zhu   Comp.Science   Apr 14 2020  Final version.
*/

struct PolyTerm
{
	int coeff;
	int expo;
	struct PolyTerm *next;
};

struct PolyTerm* head = NULL;

//assimilate new term into the existing polynomial
int addPolyTerm(int coeff, int expo) {
	struct PolyTerm *curr, *prev;
	curr = head;

	if (head == NULL){
		struct PolyTerm* newTerm = (struct PolyTerm *)malloc(sizeof(struct PolyTerm));
    		if(newTerm == NULL) return -1;
		newTerm -> coeff = coeff;
	        newTerm -> expo = expo;
        	newTerm -> next = NULL;
		head = newTerm;
		return 0;
	}
	//only 1 item case
	else if (head->next == NULL){
	//    	printf("%d\n",head->expo);
		if (head->expo == expo){
			curr->coeff += coeff;
			return 0;
		}
		else if (head->expo > expo){
		  //  printf("here");
		  //  struct PolyTerm* temp = head;
			struct PolyTerm* newTerm = (struct PolyTerm *)malloc(sizeof(struct PolyTerm));
			newTerm -> coeff = coeff;
		    	newTerm -> expo = expo;
		    	newTerm -> next = head;
			head = newTerm;
 		//	printf("%d\n",head->expo);
			return 0;
		}
		else{
		    	struct PolyTerm* newTerm = (struct PolyTerm *)malloc(sizeof(struct PolyTerm));
			newTerm -> coeff = coeff;
		    	newTerm -> expo = expo;
			newTerm->next = curr;
			head = newTerm;
			
			return 0;
		}
	}
	// >2 items case
	else{
		prev = NULL;
		curr = head;
	//	printf("%d\n",head->expo);
		while (curr != NULL){
			if (curr->expo == expo){
				curr->coeff += coeff;
				return 0;
			}
			else if (curr->expo < expo){
				curr = curr->next;
				if (prev == NULL)
				    prev = head;
				else
				    prev = prev->next;
			 //   prev = prev->next;
			}
			else{
				struct PolyTerm* newTerm = (struct PolyTerm *)malloc(sizeof(struct PolyTerm));
				newTerm -> coeff = coeff;
			    	newTerm -> expo = expo;
			    	newTerm -> next = curr;
			    	if (!prev){
			        	head = newTerm;
			    	}
			    	else
			        	prev->next = newTerm;
					return 0;
			}
		}
		struct PolyTerm* newTerm = (struct PolyTerm *)malloc(sizeof(struct PolyTerm));
		newTerm -> coeff = coeff;
	    	newTerm -> expo = expo;
	        newTerm -> next = NULL;
		prev->next = newTerm;
	}
	return 0;

}

//display polynomial expression
void displayPolynomial() {
	struct PolyTerm *tmp = head;
	while((tmp != NULL) && (tmp->next != NULL)) {
		//positive term
		if(tmp->next->coeff >= 0){
			printf("%dx%d+", tmp->coeff, tmp->expo);
		}
		//negative term
		else{
			printf("%dx%d", tmp->coeff, tmp->expo);
		}
		tmp = tmp->next;
	}
	//the last term
	if((tmp != NULL) && (tmp->next == NULL)) printf("%dx%d\n", tmp->coeff, tmp->expo);
}

//evaluate the polynomial
int evaluatePolynomial(int x) {
	struct PolyTerm *tmp = head;
	int result = 0;
	while(tmp != NULL) {
		result += tmp->coeff*powi(x, tmp->expo);
		tmp = tmp->next;		
	}
	return result;
}











