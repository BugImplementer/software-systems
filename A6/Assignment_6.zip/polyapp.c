#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "utils.h"
#include "poly.h"

/*
 Program to implement a simple application that constructs
 a polynomial expression and evaluates it for certain predetermined values
 **********************************************************
 * Author      Dept.          Date         Notes
 **********************************************************
 * Xinyi Zhu   Comp.Science   Apr 12 2020  Initial version.
 * Xinyi Zhu   Comp.Science   Apr 12 2020  Added error handling.
 * Xinyi Zhu   Comp.Science   Apr 13 2020  Final version.
*/

void main(int argc, char* argv[]) {
	if(argc != 2) {
		puts("usage error: need to pass a data file as argument");
		exit(1);
	}
	
	FILE *file = fopen(argv[1],"r");
	if(file == NULL) {
		puts("File does not exist");
		exit(2);
	}

	char buffer[50];
	int coeff, expo;
	//char* tmp = fgets(buffer,50,file);
	//printf("%s",buffer); 
	//printf("%s",tmp);
	 
	while(fgets(buffer,50,file)) {
		//printf("%s",buffer);
	
		parse(buffer, &coeff, &expo);
		//printf("%d\n",coeff);
		//printf("%d\n",expo);
	
		int value = addPolyTerm(coeff, expo);
		//printf("%d",value);
		if(value == -1) break;
	}

	displayPolynomial();
	int x[20] = {-2,-1,0,1,2};
	int y;
	int ind = 0;
	while(ind < 5) {
		y = evaluatePolynomial(x[ind]);
		printf("for x=%d, y=%d\n", x[ind],y);
		ind++;
	}


}




















